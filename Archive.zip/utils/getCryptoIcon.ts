export function getCryptoIcon(symbol: string): string {
  return `https://shuffle.com/icons/crypto/${symbol.toLowerCase()}.svg`;
}

